DROP FUNCTION IF EXISTS pg_catalog.mod(varchar, int4);
DROP FUNCTION IF EXISTS pg_catalog.mod(int4, varchar);
DROP FUNCTION IF EXISTS pg_catalog.mod(int8, varchar);
DROP FUNCTION IF EXISTS pg_catalog.mod(varchar, int8);
DROP FUNCTION IF EXISTS pg_catalog.mod(char, char);
DROP FUNCTION IF EXISTS pg_catalog.mod(varchar, varchar);

drop function if exists pg_catalog.b_extract(text, date);
