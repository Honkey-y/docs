#!/usr/bin/env python
# coding=utf-8
"""
Description: PL/Java jar distribution to OBS
Copyright (c) Huawei Technologies Co., Ltd. 2018-2020. All rights reserved.
Created: 2018-10-30
Modified: 2020-01-06
"""
import subprocess
import os
import sys
import re
import commands

def download(ak, sk, srcPath, region, bucket, tmpDir):

	errCodeBaseException = 96
	errCodeIOError = 97
	errCodeIncorrectRegin = 98
	errCodeInvalidArgument = 99
	errMsg = ''
	domain = ''

	try:

		with open(tmpDir+'/../../../etc/region_map') as file_regionmap:
		    region_map = file_regionmap.read()
		file_regionmap.close()
		domains = re.findall('"'+region+'": "(.+?)"', region_map)
		if (domains != None and len(domains) > 0):
			domain = domains[0]
		else:
			errMsg = "Invalid argument: must set correct region."
			os._exit(errCodeIncorrectRegin)

		currentDir = os.getcwd()
		os.chdir(tmpDir)

		args = '%s %s %s 3 %s 443 download %s ' % (ak, sk, srcPath, domain, bucket)
		p = subprocess.Popen([tmpDir+'/../../../jdk/bin/java', '-jar', '/tools/udstool.jar'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, close_fds=True)
		res = p.communicate(args)

		os.chdir(currentDir)

		if p.returncode != 0:
			errMsg = "udstool download failed: %s %s" % (res[0], res[1])
			print errMsg, p.returncode
			os._exit(p.returncode)
		else:
			os._exit(0)

	except BaseException as err:
		errMsg = 'udstool download except: %s' % str(err)
		print errMsg
		os._exit(errCodeBaseException)

	except IOError as err:
		errMsg = 'udstool file is not accessible' % str(err)
		print errMsg
		os._exit(errCodeIOError)

def main():
	if len(sys.argv) != 7:
		errMsg = 'Invalid argument: must set 7 correct arguments.'
		print errMsg
		os._exit(errCodeInvalidArgument)
	else:
		download(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])

if __name__ == '__main__':
	main()
