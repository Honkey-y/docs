/* -------------------------------------------------------------------------
 *
 * item.h
 *	  openGauss disk item definitions.
 *
 *
 * Portions Copyright (c) 1996-2012, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 * src/include/storage/item/item.h
 *
 * -------------------------------------------------------------------------
 */
#ifndef ITEM_H
#define ITEM_H

typedef Pointer Item;

#endif /* ITEM_H */
